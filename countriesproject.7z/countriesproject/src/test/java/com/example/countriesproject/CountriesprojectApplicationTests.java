package com.example.countriesproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountriesprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}

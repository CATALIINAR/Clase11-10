package com.example.countriesproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountriesprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(CountriesprojectApplication.class, args);
    }

}
